<?php 

if(isset($_POST['submit'])){
    
   $email = ($_POST['email']);
    $password = ($_POST['password']);
    
$connection = mysqli_connect('localhost' , 'root' , '' ,'login_user' );
    if($connection){
        echo"Data base connected";
    }
    else{
        die("database connection field");
    }
    $query = "SELECT * 
		FROM users
		WHERER email = '$email' AND password = '$password'";
    
    $result = mysqli_query($connection , $query);

	while($row = mysqli_fetch_array($result)){
		print_r($row);
	}
    
    if(!$result){
        die('query field'  .mysqli_error());
    }
}

?>



<!DOCTYPE.html>
<html lang="en">
<head>
<title>Manel Shopping Center</title>
<meta charset="utf-8">
<meta name="viewport"
content="width=device-width,initial-scale=1">
</head>
<body>

<form type=""  action="login.php"  method="POST">
<lable>Username</lable>
<input type="text"   name="email" ><br><br>
<lable>PASSOWRD</lable>
<input type="password"   name="password" ><br>
<input type="submit" name="submit" value="submit">

</form>


</body>
</html>
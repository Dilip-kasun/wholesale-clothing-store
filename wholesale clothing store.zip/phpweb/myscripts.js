
function formvalidation()
{
	if ((document.Loginform.pwdtxt.value)!=(document.Loginform.cpwdtxt.value))
	{
	alert ("Password must be equal");
	Loginform.pwdtxt/focus();
	return (false);
	}
	else
	{
		return (true);
		}

var fname=document.getElementById('fname').value;
if (fname == ""){
	document.getElementById('username').innerHTML"please fill in the first name";

	return.false;
}


}


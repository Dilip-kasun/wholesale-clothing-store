<?php include("server.php");

    $id = $_GET['id'];
    $type = "Cansel";
    $insert="update orders set action='".$type."'  where id='".$id."'";
        if($conn->query($insert) === TRUE){
        echo "<script>
        alert('Appointment Cansel');
        
        </script>"; 
        }else{
            echo "<script>
        alert('Update Succesffull');
       
        </script>";
        }

 echo "<script>
        
        window.location.href='http://localhost/phpweb/admin-viewOrders.php';
        </script>"; 

?>
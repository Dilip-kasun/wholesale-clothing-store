<!DOCTYPE.html>
<html lang="en">
<head>
<title>Mask shopping</title>
<meta charset="utf-8">
<meta name="viewport"
content="width=device-width,initial-scale=1">
<link href="style.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>

input[type=text2], select, textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    margin-top: 6px;
    margin-bottom: 16px;
    resize: vertical;
}

input[type=submit] {
    background-color: #4CAF50;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

.container1 {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}
.content
{
	font-size:18px;
	font-weight:bold;
	font-family:serif;
  

	
}
	.content2
{
	font-size:18px;
	font-weight:bold;
	font-family:serif;
   border:4px solid black;
	
}


</style>


</head>
<body>

<div class="header"><img id="logo" src="mask1.jpg">
	<h1>Mask Online Clothing Store</h1>
	
	</div>
<div class="topnav">
		<a href="web.html">Home</a>
		<a href="men.html">Men</a>
		<a href="women.html">Women</a>
		<a href="kids.html">Kids</a>
		<a href="contactus.html">Contact us</a>
		<a href="myaccount.html">My Account</a>
		<a href="register.html" class="right">Register</a>
		<a href="sing in.html" class="right">Log In</a>

<form class="search-form">
	<input type="text1" placeholder="Search your favourite..">
	<button1>search</button1>
	</form>
	</div>
	</div>

<br><br><br><br>
<h1  style="front-size:72px; font-weight=bold">Contact Us</h1>
<br>
</hr>
<h2>Thank you visit the MASK website.we value you thoughts,suggestions and comment regarding any aspect of the MASK
experience.<br>Please contact us by completing the form below.You will receive a reply from us shortly.</h2><br><br>
<hr>
<div class="row" >
<div class="column1" >
<div class="content">
	<h1>Head Office</h1>
<br><br>

MASK</br>
No 5,Alexandra Place,colombo 7,Sri Lanka<br>
Telephone : +94114-655800<br>
Telephone : +94114-725800<br>
FAX 	  : +94112-871333<br>
E-Mail    : inform@mask.com<br>
<br><br>
Online Shopping Queries<br>
Hotline : +94114-725800<br>
Telephone : +94114-655800<br>
Telephone : +94114-725800<br>
FAX 	  : +94112-871333<br>
E-Mail    : myoderm@mask.com<br>

</div>
</div>
<div class="column1" >
<div class="content">
	<h1>MASK Alexandra Office</h1>
<br><br>

Kotte road,
Rajagiriya,Sri Lanka.<br>
Telephone : +94114-625700<br>
FAX 	  : +94112-871333<br><br><br>

Bridal Register Queries:</br>
Telephone : +94114-625800<br>
Telephone : +94114-622200<br>
E-Mail    : bridal@mask.com

</div>
</div>
<div class="column1" >
<div class="content2">
<h1>By Email</h1>


<?php 

if(isset($_POST['submit'])){

$firstname = ($_POST['firstname']);
$lastname = ($_POST['lastname']);
$email = ($_POST['email']);
$city = ($_POST['city']);
$subject = ($_POST['subject']);


$connection = mysqli_connect('localhost' , 'root' , '' ,'contact' );
 if($connection){
        echo"Data base connected"."<br>";
    }
    else{
        die("database connection field");
    }
	
	if( !empty($firstname) && !empty($lastname) && !empty($email) && !empty($city) && !empty($subject)){
    $query = "INSERT INTO email(firstname ,lastname,email,city,subject)";
    $query .="VALUES ('$firstname' ,'$lastname' , '$email' , '$city' , '$subject')";
    
    $result = mysqli_query($connection , $query);
    
    if(!$result){
        die('query field'  .mysqli_error());
    }
    
        }
    
    


}

?>




















<div class="container">
  <form action="contactus.php" method="post">
	<label for="fname">First Name</label>
	 <input type="text2" id="fname" name="firstname" placeholder="Your name.."required>

	<label for="lname">Last Name</label>
	<input type="text2" id="lname" name="lastname" placeholder="Your last name.."required>

	<label for="email">Email</label>
	<input type="email" id="email" name="email" placeholder="Enter email"required>
    <label for="city">City</label>
    <select id="city" name="city">
      <option value="kandy">Kandy</option>
      <option value="Colombo">Colombo</option>
      <option value="other">Other</option>
    </select>

    <label for="subject">Subject</label>
    <textarea id="subject" name="subject" placeholder="Write something.."required style="height:200px"></textarea>

    <input type="submit" name="submit" value="submit">
  </form>
</div>


</div>
</div>
</div>





<div class="footer">
<div class="container">
<div class="row">
<div class="column">
	<h1>Customer Services</h1>
	<h4>Contact Us</h4>
	<h4>Feedback</h4>
	<h4>>FAQS</h4>
	<h4>Return Policy</h4>
	<h4>Side Guide</h4>
	
	
</div>
<div class="column">
	<h1>About us</h1>
	<h4>Sell with us</h4>
	<h4>Privacy Policy</h4>
	<h4>Term & Condition</h4>
</div>
<div class="column">
<h1>Payment</h1>
	<i class="fa fa-cc-visa" style="font-size:36px" ></i> 
	<i class="fa fa-cc-paypal" style="font-size:36px"></i><br>
	<i class="fa fa-cc-mastercard" style="font-size:36px"></i>
	<i class="fa fa-cc-creditcard" style="font-size:36px"></i>
	<i class="fa fa-cc-amex" style="font-size:36px"></i>
</div>
<div class="column">
<h1>Follow Us On Social</h1><br>
	
<div class="icon-bar">
	<a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
	<a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
	<a href="#" class="google"><i class="fa fa-google"></i></a>
	<a href="#" class="youtube"><i class="fa fa-youtube"></i></a>
	
	</div>
</div>
</div>
</div>
</div>


</body>
</html>
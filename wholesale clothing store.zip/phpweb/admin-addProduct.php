<?php 
include('server.php');
session_start();
   
    $sql = "select * from product";
    $result = mysqli_query($conn,$sql);

if(isset($_POST['submit'])){
    $cat = $_POST['category'];
    $product = $_POST['product'];
    
    $insert = "insert into product(categoryName,productName) values ('".$cat."','".$product."')";
    mysqli_query($conn,$insert);
    echo '<script>alert("New product is inserted sucessfully")</script>';
}

?>

<!DOCTYPE.html>
<html lang="en">
<head>
<title>Manel Shopping Center</title> 
<meta charset="utf-8">
<meta name="viewport"
content="width=device-width,initial-scale=1">
<link href="style.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
    body{
	margin:0;
	padding:20px;
	font-family: sans-serif;
}

*{
	box-sizing: border-box;
}

.table{
	width: 100%;
	border-collapse: collapse;
}

.table td,.table th{
  padding:12px 15px;
  border:1px solid #ddd;
  text-align: center;
  font-size:16px;
}

.table th{
	background-color: darkblue;
	color:#ffffff;
}

.table tbody tr:nth-child(even){
	background-color: #f5f5f5;
}

/*responsive*/

@media(max-width: 500px){
	.table thead{
		display: none;
	}

	.table, .table tbody, .table tr, .table td{
		display: block;
		width: 100%;
	}
	.table tr{
		margin-bottom:15px;
	}
	.table td{
		text-align: right;
		padding-left: 50%;
		text-align: right;
		position: relative;
	}
	.table td::before{
		content: attr(data-label);
		position: absolute;
		left:0;
		width: 50%;
		padding-left:15px;
		font-size:15px;
		font-weight: bold;
		text-align: left;
	}
}

    
    </style>
</head>
<body>

<div class="header"><img id="logo" src="bg.jpg">
	<h1>Manel Shopping Center</h1>
	
	</div>
<div class="topnav">
		<a href="admin-viewOrders.php">View Orders</a>
		<a href="admin-addCategory.php">Add Category</a>
        <a href="admin-addProduct.php">Add Product</a>
		<a href="logout.php" class="right">Logout</a>


	</div>
    
    <div class="column1" style="margin-left: 35%;">
		
		 <div class="Text4">
		
		 
			<form  action="" method = "post" name="Loginform"  >
                
                <label for="category"><b>Category Name</b></label>
                <select name="category">
                    <?php $sql1 = "select cname from category";
                     $result1 = mysqli_query($conn,$sql1);
                    while($row=mysqli_fetch_array($result1)){ ?>
                        <option><?php echo $row['cname']; ?></option>
                    <?php } ?>
                    
                </select>
			
			 <label for="product"><b>Product Name</b></label>
    <input type="text" placeholder="Product name.." required name="product" >
                
    	
      <button input type="submit" name="submit"  value="submit" class="signupbtn">Add Product</button>
		
	
  </form>
	</div>
		</div>
		
    
     <table class="table">
     <thead>
     	<tr>
     	 <th>ID</th>
     	 <th>Category Name</th>
        <th>Product Name</th>
     	</tr>
     </thead>
     <tbody>
     	  <?php while($row=mysqli_fetch_array($result)){ ?>
             <tr>
     	  	  <td data-label="S.No"><?php echo $row['pid']; ?></td>
     	  	  <td data-label="Name"><?php echo $row['categoryName']; ?></td>
                 <td data-label="Name"><?php echo $row['productName']; ?></td>
     	  	  
     	  </tr>
        <?php } ?>
         </tbody>
    </table>



</body>
</html>
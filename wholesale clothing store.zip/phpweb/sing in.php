<?php 
include('server.php');

session_start();
if(isset($_POST['submit'])){

    $email = $_POST['email'];
     $password = $_POST['password'];
    
    $sql = "select type from users where email='".$email."' and password='".$password."'";
    
    $result = mysqli_query($conn,$sql);
    
    if($row = mysqli_fetch_array($result)){
        if($row['type']=='user'){
             $_SESSION['email'] = $email;
         echo "<script>
        alert('Login Succesffull');
        window.location.href='http://localhost/phpweb/user-order.php';
        </script>"; 
        }
       
        else if($row['type']=='admin'){
         echo "<script>
        alert('Login Succesffull');
        window.location.href='http://localhost/phpweb/admin-viewOrders.php';
        </script>"; 
        }else{
         echo "<script>
        alert('Login Failed!');
        window.location.href='http://localhost/phpweb/sing%20in.php';
        </script>"; 
    }
        
}
}






?>








<!DOCTYPE.html>
<html lang="en">
<head>
<title>Manel Shopping Center</title>
<meta charset="utf-8">
<meta name="viewport"
content="width=device-width,initial-scale=1">
<link href="style.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
input[type=email], input[type=password] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

input[type=submit]{
    background-color: #4CAF50;
    color: white;
    padding: 10px 15px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
}
p.singup.button{
    background-color: #4CAF50;
    color: white;
    padding: 10px 15px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 25%;
}


input[type=submit]:hover {
    opacity: 0.8;
}

.cancelbtn {
    width: auto;
    padding: 5px 10px;
    background-color: #f44336;
	float:left;
	
}



.container1 {
    padding: 16px;
	border:8px solid black;
	height:auto;
	
}



span.psw 
{	
	 float: right;
	padding-top: 16px;
	
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
}






</style>

</head>
<body>

<div class="header"><img id="logo" src="bg.jpg">
	<h1>Manel Shopping Center</h1>
	
	</div>
<div class="topnav">
		<a href="web.html">Home</a>
		<a href="men.html">Men</a>
		<a href="women.html">Women</a>
		<a href="kids.html">Kids</a>
		<a href="contactus.html">Contact us</a>
		<a href="myaccount.html">My Account</a>
		<a href="Register.php" class="right">Register</a>
		<a href="sing in.php" class="right">Log In</a>
/a>

<form class="search-form">
	<input type="text1" placeholder="Search your favourite..">
	<button1>search</button1>
	</form>
	</div>
	</div>

<div style="background-color:#e5e5e5;padding:15px;text-align:center;">
  <h1>Login</h1>
</div>

<div class="row" >
<div class="column1" >
<div class="content">

</div>
</div>
<div class="column1" >
<div class="content">
	
	<a href="register.html"><p class="singup button">
    <input type="submit" value="Sing up" onclick="Register.html"/>
	</p></a>
	 <div class="container1">
	<h2>Registered Customer</h2>
<p>If you have already registered as our customer, please sing in.</p>
		<br><br>
    <label for="uname"><b>Enter E-mail</b></label>
 <form name="signup" action="" method="post">
    <input type="email" placeholder="Enter E-mail" required name="email" required>
	<br><br>
    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" required name="password" required>
        `<br><br>
   	<input type="submit" value="submit" name="submit" >
		<br><br>
    <label>
      <input type="checkbox" checked="checked" name="remember"> Remember me
    </label>
	
	<div style="background-color:#e5e5e5; padding:30px">
	<button type="button" class="cancelbtn">Cancel</button>
    <span class="psw">Forgot <a href="#">password?</a></span>

  </div>
         </form>
  </div>


</div>
</div>
<div class="column1" >
<div class="content">


</div>
</div>
</div>




<div class="footer">
<div class="container">
<div class="row">
<div class="column">
	<h1>Customer Services</h1>
	<h4>Contact Us</h4>
	<h4>Feedback</h4>
	<h4>>FAQS</h4>
	<h4>Return Policy</h4>
	<h4>Side Guide</h4>
	
	
</div>
<div class="column">
	<h1>About us</h1>
	<h4>Sell with us</h4>
	<h4>Privacy Policy</h4>
	<h4>Term & Condition</h4>
</div>
<div class="column">
<h1>Payment</h1>
	<i class="fa fa-cc-visa" style="font-size:36px" ></i> 
	<i class="fa fa-cc-paypal" style="font-size:36px"></i><br>
	<i class="fa fa-cc-mastercard" style="font-size:36px"></i>
	<i class="fa fa-cc-creditcard" style="font-size:36px"></i>
	<i class="fa fa-cc-amex" style="font-size:36px"></i>
</div>
<div class="column">
<h1>Follow Us On Social</h1><br>
	
<div class="icon-bar">
	<a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
	<a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
	<a href="#" class="google"><i class="fa fa-google"></i></a>
	<a href="#" class="youtube"><i class="fa fa-youtube"></i></a>
	
	</div>
</div>
</div>
</div>
</div>


</body>
</html>
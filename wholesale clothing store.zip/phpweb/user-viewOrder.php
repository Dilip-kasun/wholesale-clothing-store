<?php 
include('server.php');
session_start();
    $email = $_SESSION['email'];
    $sql = "select * from orders where email='".$email."'";
    $result = mysqli_query($conn,$sql);

?>

<!DOCTYPE.html>
<html lang="en">
<head>
<title>Manel Shopping Center</title>
<meta charset="utf-8">
<meta name="viewport"
content="width=device-width,initial-scale=1">
<link href="style.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
    body{
	margin:0;
	padding:20px;
	font-family: sans-serif;
}

*{
	box-sizing: border-box;
}

.table{
	width: 100%;
	border-collapse: collapse;
}

.table td,.table th{
  padding:12px 15px;
  border:1px solid #ddd;
  text-align: center;
  font-size:16px;
}

.table th{
	background-color: darkblue;
	color:#ffffff;
}

.table tbody tr:nth-child(even){
	background-color: #f5f5f5;
}

/*responsive*/

@media(max-width: 500px){
	.table thead{
		display: none;
	}

	.table, .table tbody, .table tr, .table td{
		display: block;
		width: 100%;
	}
	.table tr{
		margin-bottom:15px;
	}
	.table td{
		text-align: right;
		padding-left: 50%;
		text-align: right;
		position: relative;
	}
	.table td::before{
		content: attr(data-label);
		position: absolute;
		left:0;
		width: 50%;
		padding-left:15px;
		font-size:15px;
		font-weight: bold;
		text-align: left;
	}
}

    
    </style>


</head>
<body>

<div class="header"><img id="logo" src="bg.jpg">
	<h1>Manel Shopping Center</h1>
	
	</div>
<div class="topnav">
		<a href="user-order.php">Order</a>
		<a href="user-viewOrder.php">View Orders</a>
		<a href="logout.php" class="right">Logout</a>


	</div>
    
    


   <table class="table">
     <thead>
     	<tr>
     	 <th>Category</th>
     	 <th>Product</th>
     	 <th>Qty</th>
     	 <th>Date</th>
     	 <th>Action</th>
     	</tr>
     </thead>
     <tbody>
     	  <?php while($row=mysqli_fetch_array($result)){ ?>
             <tr>
     	  	  <td data-label="S.No"><?php echo $row['category']; ?></td>
     	  	  <td data-label="Name"><?php echo $row['product']; ?></td>
     	  	  <td data-label="Age"><?php echo $row['qty']; ?></td>
     	  	  <td data-label="Marks%"><?php echo $row['orderDate']; ?></td>
     	  	  <td data-label="Staus"><?php echo $row['action']; ?></td>
     	  </tr>
        <?php } ?>
       </tbody>
    </table>


</body>
</html>
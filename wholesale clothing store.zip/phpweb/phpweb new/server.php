<?php
	
	$firstname ="";
	$lastname ="";
	$email ="";
	$errors = array();
	
	$dbServername ="localhost";
	$dbUsername ="root";
	$dbPassword ="";
	$dbname ="registration"
	
	$conn = mysqli_connect($dbServername,$dbUsername ,$dbPassword,	$dbname);
	
	if (isset($_POST['Register'})) {
		$firstname = mysql_real_escape_string($_POST['firstname']);
		$laststname = mysql_real_escape_string($_POST['lastname']);
		$email = mysql_real_escape_string($_POST['email']);
		$pwdtxt = mysql_real_escape_string($_POST['pwdtxt']);
		$cpwdtxt = mysql_real_escape_string($_POST['cpwdtxt']);
		
		//ensure that form field are filled properly
			if(empty($firstname)){
				array_push($errors,"firstname is required");
			}
				if(empty($lastname)){
				array_push($errors,"lastname is required");
			}
				
				if(empty($email)){
				array_push($errors,"Email is required");
			}
				if(empty($pwdtxt)){
				array_push($errors,"Password is required");
			}
				if($pwttxt != $cpwdtxt){
					array_push($errors ,"The two password not match");
				}
			//if there no errors, save user to database
				if(count($errors)==0){
					$sql ="INSERT INTO users(firstname ,lastname,email,password)
								VALUES('$firstname' , '$lastname' , '$email' ,'$pwdtxt')";
								
								mysqli_query($conn ,$sql);
								
								if($conn->query($sql)){
				echo "New record is inserted sucessfully";
			}
			else{
				echo"Error:".$sql ."<br>".$conn->error;
			}
				}
				
	}	
	
	

	
	?>
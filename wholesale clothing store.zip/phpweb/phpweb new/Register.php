



<!DOCTYPE.html>
<html lang="en">
<head>
<title>Mask shopping</title>
<meta charset="utf-8">
<meta name="viewport"
content="width=device-width,initial-scale=1">
<link href="style.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<script>
/*		function formvalidation()
		{
			var passwordid = document.getElementById("pass");
				if ((passwordid.value.length <= 8)){
				alert('Enter atleast 8 characters');
				return false;
			}

			if ((document.Loginform.pwdtxt.value)!=(document.Loginform.cpwdtxt.value))
			{
			alert ("Password must be equal");
			Loginform.pwdtxt/focus();
			return (false);
			}
			else
			{
				return (true);
				}
		}

		*/	

		</script>
		
		




		</head>
<body>

<div class="header"><img id="logo" src="mask1.jpg">
	<h1>Mask Online Clothing Store</h1>
	
	</div>
<div class="topnav">
		<a href="web.html">Home</a>
		<a href="men.html">Men</a>
		<a href="women.html">Women</a>
		<a href="kids.html">Kids</a>
		<a href="contactus.html">Contact us</a>
		<a href="myaccount.html">My Account</a>
		<a href="register.html" class="right">Register</a>
		<a href="sing in.html" class="right">Log In</a>

<form class="search-form">
	<input type="text1" placeholder="Search your favourite..">
	<button1>search</button1>
	</form>
	</div>
</div>
	

<div>
	<div class="container">
	 <div style="text-align:center">
  <div class="Text2"><h2>Sign Up</h2> </div>
    <div class="Text2"><p>Please fill this form to create an account.</p></div>
  </div>
		
		
	<div class="row">
    <div class="column1">
      <div></div>
    </div>
  
    <div class="column1" >
		<div class="container2">
		 <div class="Text4">
		
		 
		 
		 
			<form  action="Register.php" method = "post" name="Loginform" onsubmit="return formvalidation();"  >
			
			<?php 
			
			
			error_reporting(0);
			
			$fserr=$lserr=$emerr=$pserr=$cperr="";

if(isset($_POST['submit'])){
  
   $firstname = ($_POST['firstname']);
    $lastname= ($_POST['lastname']);
	   $email = ($_POST['email']);
    $password= ($_POST['password']);
	    $cpwtxt= ($_POST['cpwtxt']);
    
$connection = mysqli_connect('localhost' , 'root' , '' ,'registration' );
    if($connection){
        echo"Data base connected"."<br>";
    }
    else{
        die("database connection field");
    }
	
	
	if(empty($firstname)){
				$fserr =  "firstname is required";
			}

       if(empty($lastname)){
				$lserr =  "lastname is required";
			}
			
			if(empty($email)){
				$emerr =  "email is required";
			}
			else if(!filter_var($email,FILTER_VALIDATE_EMAIL))
			{
				$emerr = "Enter the valid E-mail";
			}
			if(empty($password)){
				$pserr =  "password is required";
			}
			if(empty($cpwtxt)){
				$cperr =  "comform password is required";
			}
			if($password != $cpwtxt){
				$pserr ="Password dosen't match";
			}
    
    
if ( !empty($firstname) && !empty($lastname) && !empty($email)&& !empty($password)){
    $query = "INSERT INTO users(firstname ,lastname,email,password)";
    $query .="VALUES ('$firstname' ,'$lastname' , '$email' , '$password')";
    
    $result = mysqli_query($connection , $query);
    
    if(!$result){
        die('query field'  .mysqli_error());
    }
    
        }
    
    
    
}			
			
?>
			
			
			
			
			
			
			
			
			
			
			
			
			
			 <label for="fname"><b>First Name</b></label>
    <input type="text" placeholder="Your first name.." name="firstname">
	<span class="error"><?php echo $fserr; ?> </span><br>
			 <label for="lname"><b>Last Name</b></label>
    <input type="text" placeholder="Your last name.." name="lastname" >
	<span class="error"><?php echo $lserr; ?> </span><br>
	
		<label for="email"><b>Email</b></label>
    <input type="email" placeholder="Your e-mail address.." name="email"  >
				 <span class="error"><?php echo $emerr; ?> </span><br>
	

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" id = "pass">
	
		<span class="error"><?php echo $pserr; ?> </span><br>

    <label for="psw-repeat"><b>Repeat Password</b></label>
    <input type="password" placeholder="Repeat Password" name="cpwdtxt" >
    	<span class="error"><?php echo $cperr; ?> </span><br>

	
    <label>
      <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
    </label>
	<br>
    <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>

    
      
      <button input type="submit" name="submit"  value="submit" class="signupbtn">Sign Up</button>
		
	
	
	 <button type="reset" class="cancelbtn">Cancel</button>
    
  </form>
	</div>
		</div>
		</div>
	</div>
		 </div>
	</div>

	



<div class="footer">
<div class="container">
<div class="row">
<div class="column">
	<h1>Customer Services</h1>
	<h4>Contact Us</h4>
	<h4>Feedback</h4>
	<h4>FAQS</h4>
	<h4>Return Policy</h4>
	<h4>Side Guide</h4>
	
	
</div>
<div class="column">
	<h1>About us</h1>
	<h4>Sell with us</h4>
	<h4>Privacy Policy</h4>
	<h4>Term & Condition</h4>
</div>
<div class="column">
<h1>Payment</h1>
	<i class="fa fa-cc-visa" style="font-size:36px" ></i> 
	<i class="fa fa-cc-paypal" style="font-size:36px"></i><br>
	<i class="fa fa-cc-mastercard" style="font-size:36px"></i>
	<i class="fa fa-cc-creditcard" style="font-size:36px"></i>
	<i class="fa fa-cc-amex" style="font-size:36px"></i>
</div>
<div class="column">
<h1>Follow Us On Social</h1><br>
	
<div class="icon-bar">
	<a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
	<a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
	<a href="#" class="google"><i class="fa fa-google"></i></a>
	<a href="#" class="youtube"><i class="fa fa-youtube"></i></a>
	
	</div>
</div>
</div>
</div>
</div>


</body>
</html>
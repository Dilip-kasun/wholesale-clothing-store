<?php 
	session_start();
?>

<!DOCTYPE.html>
<html lang="en">
<head>
<title>Mask shopping</title>
<meta charset="utf-8">
<meta name="viewport"
content="width=device-width,initial-scale=1">
<link href="style.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


</head>
<body>

<div class="header"><img id="logo" src="mask1.jpg">
	<h1>Mask Online Clothing Store</h1>
	
	</div>
<div class="topnav">
		<a href="web.html">Home</a>
		<a href="men.html">Men</a>
		<a href="women.html">Women</a>
		<a href="kids.html">Kids</a>
		<a href="contactus.html">Contact us</a>
		<a href="myaccount.html">My Account</a>
		<a href="register.html" class="right">Register</a>
		<a href="sing in.html" class="right">Log In</a>

<form class="search-form">
	<input type="text1" placeholder="Search your favourite..">
	<button1>search</button1>
	</form>
	</div>
<h3><b>Explore the latest Tops from your favorite fashion brand this season,we have the newest looks to suit your every occasion.You can't top this! 
Shop from our selection of tops for women. We have Crop Tops, Halter Top, Tank Tops, Tube Top, T-shirts, and off-shoulder tops etc.</b><h3><br>
<hr>
<h1>New Collection</h1>
<div class="row" >
<div class="column" >
<div class="content">
	<div class="container">
<img src="image/lad1.jpg" alt="Mountains" Width="100%" height ="300px" >
<div class="overlay">
<div class="text">Lipsy VIP Print One Shoulder Maxi Dress<br>price-RS:2150</div>
</div>
</div>
</div>
</div>

<div class="column" >
<div class="content">
	<div class="container">
<img src="image/lad3.jpg" alt="Mountains" Width="100%" height="300px">
<div class="overlay">
<div class="text">ORANGE FLORAL SHOULDER KEYHOLE SHORT DRESS<br>price-RS:1250.00</div>
</div>
</div>
</div>
</div>
<div class="column" >
<div class="content">
	<div class="container">
<img src="image/lad4.jpg" alt="Mountains"  Width="100%" height="300px">
<div class="overlay">
<div class="text">All Over Lace Halter Maxi Dress<br>price-RS:4500</div>
</div>
</div>
</div>
</div>
<div class="column" >
<div class="content">
	<div class="container">
<img src="image/lad5.jpg" alt="Mountains"  Width="100%" height="300px">
<div class="overlay">
<div class="text">WHITE LACE MAXI DRESS<br>price-RS:2450</div>
</div>
</div>
</div>
</div>
	</div>
<hr>
<h1>Mens collection</h1>
<div class="row">
<div class="column" >
<div class="content">
	<div class="container">
<img src="image/boy4.jpg" alt="Mountains"  Width="100%" height="300px">
<div class="overlay">
<div class="text">TIKTAULI White Colour Skinny With Zip Pocket<br>price-RS:2450</div>
</div>
</div>
</div>
</div>

<div class="column" >
<div class="content">
	<div class="container">
<img src="image/boy1.jpg" alt="Mountains"  Width="100%" height="300px">
<div class="overlay">
<div class="text">Red, White & Blue T-Shirt<br>price-RS:3250</div>
</div>
</div>
</div>
</div>
<div class="column" >
<div class="content">
	<div class="container">
<img src="image/boy2.jpg" alt="Mountains"  Width="100%" height="300px">
<div class="overlay">
<div class="text">Red, White & Blue T-Shirt<br>price-RS:3750</div>
</div>
</div>
</div>
</div>
<div class="column" >
<div class="content">
	<div class="container">
<img src="image/boy3.jpg" alt="Mountains"  Width="100%" height="300px">
<div class="overlay">
<div class="text">Plain White Men's <br>price-RS:2450</div>
</div>
</div>
</div>
</div>
	</div>
<hr>
<h1>Hats Collection</h1>
<div class="row" >
<div class="column" >
<div class="content">
	<div class="container">
<img src="image/hat3.jpg" alt="Mountains" Width="100%" height ="300px" >
<div class="overlay">
<div class="text"> Pink Hat with Brown Bow <br>price-RS:1450</div>
</div>
</div>
</div>
</div>

<div class="column" >
<div class="content">
	<div class="container">
<img src="image/hat1.jpg" alt="Mountains" Width="100%" height="300px">
<div class="overlay">
<div class="text">white Hat with Brown Bow <br>price-RS:1550</div>
</div>
</div>
</div>
</div>
<div class="column" >
<div class="content">
	<div class="container">
<img src="image/hat2.jpg" alt="Mountains"  Width="100%" height="300px">
<div class="overlay">
<div class="text">cream flora hat<br>price-RS:1450</div>
</div>
</div>
</div>
</div>
<div class="column" >
<div class="content">
	<div class="container">
<img src="image/hat4.jpg" alt="Mountains"  Width="100%" height="300px">
<div class="overlay">
<div class="text">Navy bule flora hat<br>price-RS:1150</div>
</div>
</div>
</div>
</div>
	</div>
<hr>
<h1><b>Order online to complete your look today!</b></h1><br>
<h3><b>MASK loves to make real the fantasy of picking out a whole outfit or wardrobe online in a few short clicks.Use our Lookbook page as inspiration, or just pick out clothes yourself.<br> 
Then look through our accessories section to match your new clothes with phone cases, headbands and much more until you are satisfied you will be the picture of fashion. We even stock<br>
children's fashion, so you can outfit the whole family. We courier all orders via Australia Post or Star Track and offer no-questions 7 day return on any items purchased.</b><h3><br>

<h1><b>Online Fashion Retail the Way YOU Want It!</b><h1>
<h3><b>Fashion is for everyone  and never has that been more true than in this age of digital retail. Buying clothes online has been a revelation for many shoppers, giving them easy access<br>
to a world of brands and styles they would never have been able to hear about otherwise, slashing costs from overheads and supply chains, and making buying a new wardrobe as easy as <br>
clicking some digital buttons.</b></h3>

 <h3><b>These and many other advantages make online fashion shopping the clear choice for Srilankan consumers but the promise of cheap, easy clothes is not always faithfully fulfilled. <br>
Persistent problems with product quality, shipping, reliability, and customer service keep some customers wary of buying their clothes online. That's where Shop At Kingo comes in. Simple<br>
 and unassuming in our business, clear in our goals, we aim to provide you, the consumers, with the online fashion retailer you deserve. One where buying a lovely dress or incredible <br>
accessory really is just a click away.</b></h3><br>
<div class="footer">
<div class="container">
<div class="row">
<div class="column">
	<h1>Customer Services</h1>
	<h4><a href="contactus.html">Contact Us</a></h4>
	<h4>Feedback</h4>
	<h4>>FAQS</h4>
	<h4>Return Policy</h4>
	<h4>Side Guide</h4>
	
	
</div>
<div class="column">
	<h1>About us</h1>
	<h4>Sell with us</h4>
	<h4>Privacy Policy</h4>
	<h4>Term & Condition</h4>
</div>
<div class="column">
<h1>Payment</h1>
	<i class="fa fa-cc-visa" style="font-size:36px" ></i> 
	<i class="fa fa-cc-paypal" style="font-size:36px"></i><br>
	<i class="fa fa-cc-mastercard" style="font-size:36px"></i>
	<i class="fa fa-cc-creditcard" style="font-size:36px"></i>
	<i class="fa fa-cc-amex" style="font-size:36px"></i>
</div>
<div class="column">
<h1>Follow Us On Social</h1><br>
	
<div class="icon-bar">
	<a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
	<a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
	<a href="#" class="google"><i class="fa fa-google"></i></a>
	<a href="#" class="youtube"><i class="fa fa-youtube"></i></a>
	
	</div>
</div>
</div>
</div>
</div>


</body>
</html>
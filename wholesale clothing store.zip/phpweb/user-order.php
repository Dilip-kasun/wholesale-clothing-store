<?php
include('server.php');

session_start();
$email = $_SESSION['email'];

$category = "select cname from category";
$cresult = mysqli_query($conn,$category);

$product = "select productName from product";
$presult = mysqli_query($conn,$product);


if(isset($_POST['submit'])){
    
    $category = $_POST['category'];
    $product = $_POST['product'];
    $qty = $_POST['qty'];
    
    $sql = "insert into orders (email,category,product,qty,orderDate,action) values('".$email."','".$category."','".$product."','".$qty."',NOW(),'pending')";
    if(mysqli_query($conn,$sql)){
        echo '<script>alert("Order Successful")</script>';
    }else{
        echo '<script>alert("Failed!")</script>';
    }
}
?>

<!DOCTYPE.html>
<html lang="en">
<head>
<title>Manel Shopping Center</title>
<meta charset="utf-8">
<meta name="viewport"
content="width=device-width,initial-scale=1">
<link href="style.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


</head>
<body>

<div class="header"><img id="logo" src="bg.jpg">
	<h1>Manel Shopping Center</h1>
	
	</div>
<div class="topnav">
		<a href="user-order.php">Order</a>
		<a href="user-viewOrder.php">View Orders</a>
		<a href="logout.php" class="right">Logout</a>


	</div>
    
    <div class="column1" style="margin-left: 35%;">
		
		 <div class="Text4">
		
		 
		 
		 
	<form  action="" method = "post" name="Loginform"  >
			

			
    <label for="category"><b>Select Category</b></label>
    <select name="category">
        <?php while($row=mysqli_fetch_array($cresult)){ ?>
            
     	  	  
     	  	 <option><?php echo $row['cname']; ?></option>
              
     	 
        <?php } ?>
    </select>
	
    <label for="product"><b>Select Product</b></label>
    <select name="product">
         	 <?php while($row=mysqli_fetch_array($presult)){ ?>
            
     	  	  
     	  	 <option><?php echo $row['productName']; ?></option>
              
     	 
        <?php } ?>
    </select>
        
    <label for="email"><b>Quantity</b></label>
    <input type="number" placeholder="Qty" required name="qty"  >
      
    <button input type="submit" name="submit"  value="submit" class="signupbtn">Order Now</button>
    
  </form>
	</div>
		</div>
		



</body>
</html>
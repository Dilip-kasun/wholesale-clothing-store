<?php 
session_start();
session_destroy();
                    
echo "<script>
        alert('logout Succesffull');
        window.location.href='http://localhost/phpweb/web.html';
        </script>"; 


?>
<?php
	
	$firstname ="";
	$lastname ="";
	$email ="";
	$errors = array();
	
	$dbServername ="localhost:3306";
	$dbUsername ="root";
	$dbPassword ="";
	$dbname ="registration";
	
	$conn = mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbname);
	
	
	?>